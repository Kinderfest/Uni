package de.ur.mi.mspwddhs.campusapp.mensa;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import de.ur.mi.mspwddhs.campusapp.MainActivity;
import de.ur.mi.mspwddhs.campusapp.R;
import de.ur.mi.mspwddhs.campusapp.database.Database;
import de.ur.mi.mspwddhs.campusapp.grips.GripsActivity;
import de.ur.mi.mspwddhs.campusapp.mail.MailActivity;
import de.ur.mi.mspwddhs.campusapp.mensa.MensaController.OnResultListener;
import de.ur.mi.mspwddhs.campusapp.plan.PlanActivity;


public class MensaActivity extends ActionBarActivity implements OnResultListener {
	
	
	private ArrayList<String> content = new ArrayList<String>();
	private Database db;
	MensaController Maike;
	ProgressDialog progressDialog;
	AlertDialog.Builder alertDialogBuilder;
	ExpandableListView listView;
	Calendar calendar;
	MensaListAdapter mensaListAdap;
	TextView text;	
	ImageButton buttonGrips;
	ImageButton buttonMensa;
	ImageButton buttonEmail;
	String monday;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mensa);
		initDB();
		doIt();
		CreateDialogs();
		progressDialog.show();
		Maike = new MensaController(this,this,db);
		checkDatabase();	
	}
	
	private void doIt() {
		buttonGrips = (ImageButton) findViewById(R.id.grips);
		buttonMensa = (ImageButton) findViewById(R.id.mensa);
		buttonEmail = (ImageButton) findViewById(R.id.mail);
		buttonMensa.setBackgroundColor(getResources().getColor(R.color.heidenelke));
	}

public void onClick(View v) {
	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
	if (ClickedButton == buttonGrips) {
		Intent grips = new Intent(MensaActivity.this, GripsActivity.class);
		grips.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(grips);
	}
	if (ClickedButton == buttonEmail) {
		Intent mail = new Intent(MensaActivity.this, MailActivity.class);
		mail.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(mail);
	}
}
	
	private void CreateDialogs()
	{
		//ProgressDialog
		progressDialog = new ProgressDialog(this);
		progressDialog.setTitle(getString(R.string.updating_title));
		progressDialog.setMessage(getString(R.string.updating_text));
		progressDialog.setCanceledOnTouchOutside(false);
		progressDialog.setCancelable(false);
		
		//AlertDialog
		alertDialogBuilder = new AlertDialog.Builder(this);
		alertDialogBuilder.setTitle(getString(R.string.error_title));
		alertDialogBuilder.setMessage(getString(R.string.error_text));
		alertDialogBuilder.setCancelable(false);
		alertDialogBuilder.setPositiveButton(R.string.ok_button,
				new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				}
				});
		
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void initDB() {
		db = new Database(this);
		db.open();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if( id == R.id.campusplan) {
        	startActivity(new Intent(this, PlanActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION));  	
		}
		if (id == R.id.logout) {
			db.clearDatabaseLogin();
			db.clearDatabaseGrips();
			Intent intent = new Intent(MensaActivity.this, MainActivity.class);
			intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
			startActivity(intent);
			finish();
		}
		
		if (id == R.id.mensaReload){
			db.clearDatabaseMensa();
			
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.activity_main, container, false);
			return rootView;
		}
	}


	@Override
	public void OnUpdateCompleted() {
		progressDialog.dismiss();
		createLists();
		showLegende();
	}
	
	private void showLegende() {
		TextView schweinText = (TextView) findViewById(R.id.schweinText);
		schweinText.setText(" = Schwein");
		
		ImageView schweinImage = (ImageView) findViewById(R.id.schweinImage);
		schweinImage.setBackgroundResource(R.drawable.schweinheide);
		
		TextView rindText = (TextView) findViewById(R.id.rindText);
		rindText.setText(" = Rind");
		
		ImageView rindImage = (ImageView) findViewById(R.id.rindImage);
		rindImage.setBackgroundResource(R.drawable.rindheide);
		
		TextView gefluegelText = (TextView) findViewById(R.id.gefluegelText);
		gefluegelText.setText(" = Geflügel");
		
		ImageView gefluegelImage = (ImageView) findViewById(R.id.gefluegelImage);
		gefluegelImage.setBackgroundResource(R.drawable.huhnheide);
		
		TextView fischText = (TextView) findViewById(R.id.fischText);
		fischText.setText(" = Fisch");
		
		ImageView fischImage = (ImageView) findViewById(R.id.fischImage);
		fischImage.setBackgroundResource(R.drawable.fischheide);
		
		TextView vegeText = (TextView) findViewById(R.id.vegeText);
		vegeText.setText(" = Vegetarisch");
		
		ImageView vegeImage = (ImageView) findViewById(R.id.vegeImage);
		vegeImage.setBackgroundResource(R.drawable.blatt);
		
		TextView veganText = (TextView) findViewById(R.id.veganText);
		veganText.setText(" = Vegan");
		
		ImageView veganImage = (ImageView) findViewById(R.id.veganImage);
		veganImage.setBackgroundResource(R.drawable.vegan);
		
		TextView wildText = (TextView) findViewById(R.id.wildText);
		wildText.setText(" = Wild");
		
		ImageView wildImage = (ImageView) findViewById(R.id.wildImage);
		wildImage.setBackgroundResource(R.drawable.deerheiderand);
		
		TextView lammText = (TextView) findViewById(R.id.lammText);
		lammText.setText(" = Lamm");
		
		ImageView lammImage = (ImageView) findViewById(R.id.lammImage);
		lammImage.setBackgroundResource(R.drawable.schafheide);
		
	}

	private void createLists() {
		TextView mensatitle = (TextView) findViewById(R.id.mensatitle);
		mensatitle.setText("Das gibt's diese Woche...");
		
		TextView mensaschluss = (TextView) findViewById(R.id.mensaschluss);
		mensaschluss.setText("An Guaden!");
		
		
		listView = (ExpandableListView) findViewById(R.id.mensa_week);
		mensaListAdap = new MensaListAdapter(datesOfWeek(), db, this);
		listView.setAdapter(mensaListAdap);
		listView.setGroupIndicator(null);
	
	}
	
	private ArrayList<String> datesOfWeek() {
		ArrayList<String> datesOfWeek = new ArrayList<String>();
		calendar = Calendar.getInstance();

		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

		SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
		for (int i = 0; i < 5; i++) {
			Date currentDate = calendar.getTime();
			String currentDateString = df.format(currentDate);
			datesOfWeek.add(currentDateString);
		    calendar.add(Calendar.DATE, 1);
		}
        return datesOfWeek;
	}
	
	private String getDateOfMonday() {
		calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
		Date currentDate = calendar.getTime();
		String currentDateString = df.format(currentDate);

		return currentDateString;
	}
	
	private void checkDatabase() {
		if(db.getCount(getDateOfMonday()) != true) {
			db.clearDatabaseMensa();
			Maike.execute();
			createLists();
		}
		else {
			OnUpdateCompleted();
		}
	}
}