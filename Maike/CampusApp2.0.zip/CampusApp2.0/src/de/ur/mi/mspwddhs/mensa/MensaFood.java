package de.ur.mi.mspwddhs.mensa;

public class MensaFood {

}
