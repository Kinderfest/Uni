package de.ur.mi.mspwddhs.campusapp2;

import de.ur.mi.mspwddhs.campusapp2.R;
import de.ur.mi.mspwddhs.grips.GripsActivity;
import de.ur.mi.mspwddhs.mail.MailActivity;
import de.ur.mi.mspwddhs.mensa.MensaActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.RelativeLayout;


public class MainActivity extends Activity{
	ImageButton buttonGrips;
	ImageButton buttonMensa;
	ImageButton buttonEmail;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);   
        doIt();   
    }


    private void doIt() {
    		buttonGrips = (ImageButton) findViewById(R.id.grips);
    		buttonMensa = (ImageButton) findViewById(R.id.mensa);
    		buttonEmail = (ImageButton) findViewById(R.id.mail);
    	}
    
    public void onClick(View v) {
    	buttonGrips.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	buttonMensa.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	buttonEmail.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
    	ClickedButton.setBackgroundColor(getResources().getColor(R.color.heidenelke));
    	if (ClickedButton == buttonMensa) {
    		Intent mensa = new Intent(MainActivity.this, MensaActivity.class);
    		mensa.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(mensa);
    	}
    	if (ClickedButton == buttonGrips) {
    		Intent grips = new Intent(MainActivity.this, GripsActivity.class);
    		grips.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(grips);
    	}
    	if (ClickedButton == buttonEmail) {
    		Intent mail = new Intent(MainActivity.this, MailActivity.class);
    		mail.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(mail);
    	}
    }

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
