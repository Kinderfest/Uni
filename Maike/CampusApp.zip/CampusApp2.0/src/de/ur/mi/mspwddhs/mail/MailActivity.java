package de.ur.mi.mspwddhs.mail;

public class MailActivity {

}
