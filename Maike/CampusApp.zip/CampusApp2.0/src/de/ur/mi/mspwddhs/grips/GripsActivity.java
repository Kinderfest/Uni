package de.ur.mi.mspwddhs.grips;

public class GripsActivity {

}
