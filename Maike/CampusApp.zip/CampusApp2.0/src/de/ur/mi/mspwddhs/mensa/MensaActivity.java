package de.ur.mi.mspwddhs.mensa;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import de.ur.mi.mspwddhs.campusapp2.Database;
import de.ur.mi.mspwddhs.campusapp2.MainActivity;
import de.ur.mi.mspwddhs.campusapp2.R;
import de.ur.mi.mspwddhs.grips.GripsActivity;
import de.ur.mi.mspwddhs.mail.MailActivity;
import de.ur.mi.mspwddhs.mensa.MensaController.OnResultListener;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.TextView;


public class MensaActivity extends ActionBarActivity implements OnResultListener {
	
	
	private ArrayList<String> content = new ArrayList<String>();
	private Database db;
	MensaController Maike;
	ProgressDialog progressDialog;
	AlertDialog.Builder alertDialogBuilder;
	ExpandableListView listView;
	Calendar calendar;
	MensaListAdapter mensaListAdap;
	TextView text;	
	ImageButton buttonGrips;
	ImageButton buttonMensa;
	ImageButton buttonEmail;
	String monday;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mensa);
		initDB();
		doIt();
		CreateDialogs();
		progressDialog.show();
		Maike = new MensaController(this,this,db);
		checkDatabase();	
	}
	
	private void doIt() {
		buttonGrips = (ImageButton) findViewById(R.id.grips);
		buttonMensa = (ImageButton) findViewById(R.id.mensa);
		buttonEmail = (ImageButton) findViewById(R.id.mail);
	}

public void onClick(View v) {
	buttonGrips.setBackgroundColor(getResources().getColor(R.color.light_grey));
	buttonMensa.setBackgroundColor(getResources().getColor(R.color.light_grey));
	buttonEmail.setBackgroundColor(getResources().getColor(R.color.light_grey));
	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
	ClickedButton.setBackgroundColor(getResources().getColor(R.color.heidenelke));
	if (ClickedButton == buttonGrips) {
		Intent grips = new Intent(MensaActivity.this, GripsActivity.class);
		grips.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(grips);
	}
	if (ClickedButton == buttonEmail) {
		Intent mail = new Intent(MensaActivity.this, MailActivity.class);
		mail.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(mail);
	}
}
	
	private void CreateDialogs()
	{
		//ProgressDialog
		progressDialog = new ProgressDialog(this);
		progressDialog.setTitle(getString(R.string.updating_title));
		progressDialog.setMessage(getString(R.string.updating_text));
		progressDialog.setCanceledOnTouchOutside(false);
		progressDialog.setCancelable(false);
		
		//AlertDialog
		alertDialogBuilder = new AlertDialog.Builder(this);
		alertDialogBuilder.setTitle(getString(R.string.error_title));
		alertDialogBuilder.setMessage(getString(R.string.error_text));
		alertDialogBuilder.setCancelable(false);
		alertDialogBuilder.setPositiveButton(R.string.ok_button,
				new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				}
				});
		
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void initDB() {
		db = new Database(this);
		db.open();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.activity_main, container, false);
			return rootView;
		}
	}


	@Override
	public void OnUpdateCompleted() {
		progressDialog.dismiss();
		createLists();
	}
	
	private void createLists() {
		listView = (ExpandableListView) findViewById(R.id.mensa_week);
		mensaListAdap = new MensaListAdapter(datesOfWeek(), db, this);
		listView.setAdapter(mensaListAdap);
		listView.setGroupIndicator(null);
	
	}
	
	private ArrayList<String> datesOfWeek() {
		ArrayList<String> datesOfWeek = new ArrayList<String>();
		calendar = Calendar.getInstance();

		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

		SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
		for (int i = 0; i < 5; i++) {
			Date currentDate = calendar.getTime();
			String currentDateString = df.format(currentDate);
			datesOfWeek.add(currentDateString);
		    calendar.add(Calendar.DATE, 1);
		}
        return datesOfWeek;
	}
	
	private String getDateOfMonday()
	{
		calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
		Date currentDate = calendar.getTime();
		String currentDateString = df.format(currentDate);

		return currentDateString;
	}
	
	private void checkDatabase()
	{
		if(db.getCount(getDateOfMonday()) != true)
		{
			db.clearDatabaseMensa();
			Maike.execute();
			createLists();
		}
		else
		{
			OnUpdateCompleted();
		}
	}

}