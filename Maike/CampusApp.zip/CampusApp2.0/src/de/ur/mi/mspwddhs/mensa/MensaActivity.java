package de.ur.mi.mspwddhs.mensa;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import de.ur.mi.mspwddhs.campusapp2.MainActivity;
import de.ur.mi.mspwddhs.campusapp2.R;
import de.ur.mi.mspwddhs.mensa.MensaController.OnResultListener;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;


public class MensaActivity extends ActionBarActivity implements OnResultListener {
	
	
	private ArrayList<String> content = new ArrayList<String>();
	private MensaDatenbank db;
	MensaController Maike;
	ProgressDialog progressDialog;
	AlertDialog.Builder alertDialogBuilder;
	ListView suppe;
	Calendar calendar;
	MensaListAdapter listAdapter;
	TextView text;
   
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mensa);
		CreateDialogs();
		initDB();
		progressDialog.show();
		Maike = new MensaController(this,this,db);
		checkDatabase();
		
		
	}
	
	private void CreateDialogs()
	{
		//ProgressDialog
		progressDialog = new ProgressDialog(this);
		progressDialog.setTitle(getString(R.string.updating_title));
		progressDialog.setMessage(getString(R.string.updating_text));
		progressDialog.setCanceledOnTouchOutside(false);
		progressDialog.setCancelable(false);
		
		//AlertDialog
		alertDialogBuilder = new AlertDialog.Builder(this);
		alertDialogBuilder.setTitle(getString(R.string.error_title));
		alertDialogBuilder.setMessage(getString(R.string.error_text));
		alertDialogBuilder.setCancelable(false);
		alertDialogBuilder.setPositiveButton(R.string.ok_button,
				new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				}
				});
		
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void initDB() {
		db = new MensaDatenbank(this);
		db.open();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.activity_main, container,
					false);
			return rootView;
		}
	}


	@Override
	public void OnUpdateCompleted() {
		progressDialog.dismiss();
	}
	
	private void createLists() {
		suppe = (ListView) findViewById(R.id.suppe);
		listAdapter = new MensaListAdapter(datesOfWeek());
		suppe.setAdapter(listAdapter);
		
	}
	
	private ArrayList<String> datesOfWeek() {
		ArrayList<String> datesOfWeek = new ArrayList<String>();
		calendar = Calendar.getInstance();
		calendar.set(Calendar.WEEK_OF_YEAR, calendar.get(Calendar.WEEK_OF_YEAR));

        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy"); // PST`
        int startDate = calendar.getFirstDayOfWeek();
        
        for (int i = 0-startDate; i < 5-startDate; i++){
        	calendar.add(Calendar.DATE, i);
            Date currentDate = calendar.getTime();
            String currentDateString = formatter.format(currentDate);
            datesOfWeek.add(currentDateString);
            calendar.add(Calendar.DATE, -i);
        }
        return datesOfWeek;
	}
	
	private String getDate()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
		String currentDate = sdf.format(new Date());
		return currentDate;
	}
	
	private void checkDatabase()
	{
		if(db.getCount(getDate()) != true)
		{
			db.clearDatabase();
			Maike.execute();
		}
		else
		{
			OnUpdateCompleted();
		}
	}

}