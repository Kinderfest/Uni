package com.ur.mi.mspwddhs.mensa;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MensaDatenbank {
	
	private static final String DATABASE_NAME = "mensa.db";
	private static final int DATABASE_VERSION = 1;
	private static final String TABLE_NAME = "current";
	
	private static final String ID = "_id";
	
	private static String KEY_DATUM = "datum";
	private static String KEY_TAG = "tag";
	private static String KEY_WARENGRUPPE = "warengruppe";
	private static String KEY_NAME = "name";
	private static String KEY_KENNZ = "kennz";
	private static String KEY_PREIS = "preis";
	
	private ToDoDBOpenHelper dbHelper;

	private SQLiteDatabase db;
	
	public MensaDatenbank(Context context) {
		dbHelper = new ToDoDBOpenHelper(context, DATABASE_NAME, null,
				DATABASE_VERSION);
	}

	public void open() throws SQLException {
		try {
			db = dbHelper.getWritableDatabase();
		} catch (SQLException e) {
			db = dbHelper.getReadableDatabase();
		}
	}

	public void close() {
		db.close();
	}
	
	public void addContent(String datum, String tag, String warengruppe, String name, String kennz, String preis)
	{
		ContentValues values = new ContentValues();
		values.put(KEY_DATUM, datum);
		values.put(KEY_TAG, tag);
		values.put(KEY_WARENGRUPPE, warengruppe);
		values.put(KEY_NAME, name);
		values.put(KEY_KENNZ, kennz);
		values.put(KEY_PREIS, preis);
		
		db.insert(TABLE_NAME, null, values);
	}
	public boolean getCount(String getDatum)
	{
		Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + KEY_DATUM + "=?", new String[]{String.valueOf(getDatum)});
		cursor.moveToFirst();
		if(cursor.getInt(0) > 0)
		{
			return true;
		}
		return false;
	}
	public ArrayList<String> getContent(String getDatum) {
		ArrayList<String> content  = new ArrayList<String>();
		Cursor cursor = db.query(TABLE_NAME, new String[] { KEY_DATUM,
				KEY_TAG, KEY_WARENGRUPPE,KEY_NAME,KEY_KENNZ,KEY_PREIS }
				,KEY_DATUM + "=?", new String[]{String.valueOf(getDatum)}, null, null, null);
		
		if (cursor.moveToFirst()) 
		{
			do {
				String datum = cursor.getString(0);
				String tag = cursor.getString(1);
				String warengruppe = cursor.getString(2);
				String name = cursor.getString(3);
				String kennz = cursor.getString(4);
				String preis = cursor.getString(5);
				
				content.add(datum+";"+tag+";"+warengruppe+";"+name+";"+kennz+";"+preis);

			} while (cursor.moveToNext());
		}
		return content;
	}
	
	public void clearDatabase()
	{
		db.delete(TABLE_NAME, null, null);
	}

	private class ToDoDBOpenHelper extends SQLiteOpenHelper 
	{
		private final String DATABASE_CREATE = "create table "
			      + TABLE_NAME + " (" + ID
			      + " integer primary key autoincrement, " + KEY_DATUM
			      + " text not null, " + KEY_TAG + " text, " + KEY_WARENGRUPPE + " text, " 
			      + KEY_NAME + " text, " + KEY_KENNZ + " text, " + KEY_PREIS + " text);";

		public ToDoDBOpenHelper(Context c, String dbname,
				SQLiteDatabase.CursorFactory factory, int version) {
			super(c, dbname, factory, version);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}
	}

}