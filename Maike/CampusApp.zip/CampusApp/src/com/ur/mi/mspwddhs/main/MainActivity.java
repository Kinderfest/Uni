package com.ur.mi.mspwddhs.main;

import com.ur.mi.mspwddhs.campusapp.R;
import com.ur.mi.mspwddhs.grips.GripsActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;


public class MainActivity extends Activity{
	ImageButton buttonGrips;
	ImageButton buttonMensa;
	ImageButton buttonEmail;
	

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        doIt();
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); 
    }


    private void doIt() {
    		buttonGrips = (ImageButton) findViewById(R.id.grips);
    		buttonMensa = (ImageButton) findViewById(R.id.mensa);
    		buttonEmail = (ImageButton) findViewById(R.id.mail);
    		

    	}
    
    public void onClick(View v) {
    	buttonGrips.setBackgroundColor(Color.GRAY);
    	buttonMensa.setBackgroundColor(Color.GRAY);
    	buttonEmail.setBackgroundColor(Color.GRAY);
    	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
    	ClickedButton.setBackgroundColor(Color.RED);
    	if (ClickedButton == buttonGrips) {
    		Intent grips = new Intent(MainActivity.this, GripsActivity.class);
    		startActivity(grips);
    		
    	}
    }
		


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
