package com.ur.mi.mspwddhs.email;

public class EmailActivity {

}
