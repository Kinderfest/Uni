package com.ur.mi.mspwddhs.mensa;


import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.ur.mi.mspwddhs.campusapp.R;
import com.ur.mi.mspwddhs.mensa.MensaController.OnResultListener;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


	public class MensaActivity  extends ActionBarActivity implements OnResultListener {
		
		private ArrayList<String> content = new ArrayList<String>();
		private MensaDatenbank db;
		MensaController Maike;
		ProgressDialog progressDialog;
		AlertDialog.Builder alertDialogBuilder;
		TextView text;
		
		

		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			
			CreateDialogs();
			initDB();
			progressDialog.show();
			Maike = new MensaController(this,this,db);
			checkDatabase();
			
			
		}
		
		private void CreateDialogs()
		{
			//ProgressDialog
			progressDialog = new ProgressDialog(this);
			progressDialog.setTitle(getString(R.string.updating_title));
			progressDialog.setMessage(getString(R.string.updating_text));
			progressDialog.setCanceledOnTouchOutside(false);
			progressDialog.setCancelable(false);
			
			//AlertDialog
			alertDialogBuilder = new AlertDialog.Builder(this);
			alertDialogBuilder.setTitle(getString(R.string.error_title));
			alertDialogBuilder.setMessage(getString(R.string.error_text));
			alertDialogBuilder.setCancelable(false);
			alertDialogBuilder.setPositiveButton(R.string.ok_button,
					new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					}
					});
			
		}
		
//		private void fillTextView()
//		{
//			String Maike1 = "";
//			content = db.getContent(getDate());
//			for(int i = 0; i < content.size(); i++)
//			{
//				Maike1 = Maike1 + content.get(i);	
//			}
//			text = (TextView)findViewById(R.id.textView1);
//			text.setText(Maike1);
//		}

		@Override
		public boolean onCreateOptionsMenu(Menu menu) {

			// Inflate the menu; this adds items to the action bar if it is present.
			getMenuInflater().inflate(R.menu.main, menu);
			return true;
		}
		
		private void initDB() {
			db = new MensaDatenbank(this);
			db.open();
			//db.addContent("09.08.2014", "Sa", "HG1", "Suppe", "V", "0,80");
			//db.addContent("10.08.2014", "So", "V", "Salat", "V", "0,80");
		}

		@Override
		public boolean onOptionsItemSelected(MenuItem item) {
			// Handle action bar item clicks here. The action bar will
			// automatically handle clicks on the Home/Up button, so long
			// as you specify a parent activity in AndroidManifest.xml.
			int id = item.getItemId();
			if (id == R.id.action_settings) {
				return true;
			}
			return super.onOptionsItemSelected(item);
		}

		/**
		 * A placeholder fragment containing a simple view.
		 */
		public static class PlaceholderFragment extends Fragment {

			public PlaceholderFragment() {
			}

			@Override
			public View onCreateView(LayoutInflater inflater, ViewGroup container,
					Bundle savedInstanceState) {
				View rootView = inflater.inflate(R.layout.activity_main, container,
						false);
				return rootView;
			}
		}

		@Override
		public void OnUpdateCompleted() {
			
//			fillTextView();
			progressDialog.dismiss();
		}
		
		private String getDate()
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
			String currentDate = sdf.format(new Date());
			return currentDate;
		}
		
		private void checkDatabase()
		{
			if(db.getCount(getDate()) != true)
			{
				db.clearDatabase();
				Maike.execute();
			}
			else
			{
				OnUpdateCompleted();
			}
		}

}
