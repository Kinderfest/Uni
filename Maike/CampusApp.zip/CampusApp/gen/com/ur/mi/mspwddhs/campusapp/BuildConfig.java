/** Automatically generated file. DO NOT MODIFY */
package com.ur.mi.mspwddhs.campusapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}