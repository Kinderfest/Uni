package de.ur.mi.mspwddhs.campusapp;

import de.ur.mi.mspwddhs.campusapp.R;
import de.ur.mi.mspwddhs.campusapp.database.Database;
import de.ur.mi.mspwddhs.campusapp.grips.GripsActivity;
import de.ur.mi.mspwddhs.campusapp.mail.MailActivity;
import de.ur.mi.mspwddhs.campusapp.mensa.MensaActivity;
import de.ur.mi.mspwddhs.campusapp.plan.PlanActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;


public class MainActivity extends Activity{
	ImageButton buttonGrips;
	ImageButton buttonMensa;
	ImageButton buttonEmail;
	Database db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);   
        doIt();   
    }


    private void doIt() {
    		buttonGrips = (ImageButton) findViewById(R.id.grips);
    		buttonMensa = (ImageButton) findViewById(R.id.mensa);
    		buttonEmail = (ImageButton) findViewById(R.id.mail);
    	}
    
    public void onClick(View v) {
    	buttonGrips.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	buttonMensa.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	buttonEmail.setBackgroundColor(getResources().getColor(R.color.light_grey));
    	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
    	ClickedButton.setBackgroundColor(getResources().getColor(R.color.heidenelke));
    	if (ClickedButton == buttonMensa) {
    		Intent mensa = new Intent(MainActivity.this, MensaActivity.class);
    		mensa.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(mensa);
    	}
    	if (ClickedButton == buttonGrips) {
    		Intent grips = new Intent(MainActivity.this, GripsActivity.class);
    		grips.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(grips);
    	}
    	if (ClickedButton == buttonEmail) {
    		Intent mail = new Intent(MainActivity.this, MailActivity.class);
    		mail.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
    		startActivity(mail);
    	}
    }

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
        case R.id.about:
//        	startActivity(new Intent(this, AboutActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION));  	
        	return true;
        case R.id.help:
//        	startActivity(new Intent(this, Help.class));
        	return true;
        case R.id.campusplan:
        	startActivity(new Intent(this, PlanActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION));  	
        	return true;
        case R.id.action_settings:
//        	startActivity(new Intent(this, Help.class));
            return true;
        case R.id.logout:
//        	db.logout(); //löscht Login Daten, Grips und Email
            return true;
        default:
        return super.onOptionsItemSelected(item);
    }
}
}
