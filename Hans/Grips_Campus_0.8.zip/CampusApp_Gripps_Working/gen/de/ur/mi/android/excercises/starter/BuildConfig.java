/** Automatically generated file. DO NOT MODIFY */
package de.ur.mi.android.excercises.starter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}