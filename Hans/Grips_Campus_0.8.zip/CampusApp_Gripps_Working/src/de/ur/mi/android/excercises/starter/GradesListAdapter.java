package de.ur.mi.android.excercises.starter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class GradesListAdapter extends BaseAdapter {
	private static final int THREAD_MAX_LENGTH = 30;
	private ArrayList<Grades> data;
	private Context context;

	public GradesListAdapter(ArrayList<Grades> data, Context context) {
		this.data = data;
		this.context = context;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			LayoutInflater inflate = (LayoutInflater) this.context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflate.inflate(R.layout.grades_list_item, parent,
					false);
		}

		TextView gradeTitle = (TextView) convertView
				.findViewById(R.id.grades_list_name);
		if (data.get(position).getTaskName().length() > THREAD_MAX_LENGTH) {
			gradeTitle.setText(data.get(position).getTaskName()
					.substring(0, THREAD_MAX_LENGTH)
					+ "...");
		} else {
			gradeTitle.setText(data.get(position).getTaskName());
		}

		TextView points = (TextView) convertView
				.findViewById(R.id.grades_list_points);
		points.setText(data.get(position).getPoints());

		TextView percentile = (TextView) convertView
				.findViewById(R.id.grades_list_percentile);
		percentile.setText(data.get(position).getPoints());

		return convertView;
	}

}
