package de.ur.mi.mspwddhs.campusapp.mail;

import java.util.ArrayList;
import java.util.Collections;

import android.app.ProgressDialog;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.provider.Telephony.Sms.Conversations;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import de.ur.mi.mspwddhs.campusapp.OptionsActivity;
import de.ur.mi.mspwddhs.campusapp.R;
import de.ur.mi.mspwddhs.campusapp.database.Database;
import de.ur.mi.mspwddhs.campusapp.grips.GripsActivity;
import de.ur.mi.mspwddhs.campusapp.mail.Controller1.emailListener;
import de.ur.mi.mspwddhs.campusapp.mensa.MensaActivity;

public class MailActivity extends OptionsActivity implements emailListener {
	public static final String SUBJECT_KEY = "SUBJECT_KEY";
	public static final String USER_KEY = "USER_KEY";
	public static final String RECIPIENTS_KEY = "RECIPIENTS_KEY";
	public static final String PASSWORD_KEY = "PASSWORD_KEY";
	public static final String USERADRESS_KEY = "USERADRESS_KEY";
	private static final int RELOAD_INTERVALL = 15;

	Button checkForMails;
	ExpandableListView listView;
	ExpandableListAdapter listAdapter;

	Database db;

	Button grips;
	Button mensa;
	Button mail;

	FrameLayout footerLayout;
	Button loadMore;

	ProgressDialog dialog;
	Controller1 controller;
	Controller2 controller2;
	Answer answer;

	private int mailCounter = 0;
	private String user;
	private String password;
	private String userAdress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mail_activity_main);
		setupNavigationButtons();
		db = new Database(this);
		db.open();
		user = db.getLoginData().get(0);
		password = db.getLoginData().get(1);
		userAdress = db.getLoginData().get(2);
		controller = new Controller1(this, db);
		listView = (ExpandableListView) findViewById(R.id.expand);
		footerLayout = (FrameLayout) getLayoutInflater().inflate(
				R.layout.button_footer_view, null);
		loadMore = (Button) footerLayout.findViewById(R.id.button_moreMails);
		listView.addFooterView(footerLayout);
		loadMore.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setupList();
			}
		});
		controller.execute(user, password, userAdress);

		setupDialog();
	}

	private void setupNavigationButtons() {
		mail = (Button) findViewById(R.id.mailButton_mail);
		mail.setClickable(false);
		mail.setBackgroundColor(getResources().getColor(R.color.heidenelke));

		mensa = (Button) findViewById(R.id.mensaButton_mail);
		mensa.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MailActivity.this,
						MensaActivity.class);
				intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
				startActivity(intent);
			}
		});

		grips = (Button) findViewById(R.id.gripsButton_mail);
		grips.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MailActivity.this,
						GripsActivity.class);
				intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
				startActivity(intent);
			}
		});
	}

	private void setupDialog() {
		dialog = new ProgressDialog(this);
		dialog.setTitle("Download");
		dialog.setMessage("Emails werden heruntergeladen...");
		dialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.removeItem(R.id.refresh_mensa);
		menu.removeItem(R.id.refresh_grips);
		return true;
	}

	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	//
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// if (id == R.id.action_search) {
	// onCreate(null);
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }

	public static class PlaceholderFragment extends Fragment {
		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.mail_fragment_main,
					container, false);
			return rootView;
		}
	}

	@Override
	public void onUpdateCompleted() {
		loadMore.setVisibility(View.VISIBLE);
		setupList();
		dialog.dismiss();

	}

	private void setupList() {
		mailCounter += RELOAD_INTERVALL;
		ArrayList<Email> mails = db.getContentMail();
		ArrayList<Email> show = new ArrayList<Email>();
		Collections.reverse(mails);
		if (mails.size() > mailCounter) {
			for (int i = 0; i < mailCounter; i++) {
				show.add(mails.get(i));
			}
		} else {
			show = mails;
			loadMore.setVisibility(View.GONE);
		}
		listAdapter = new ExpandableListAdapter(show, this, this);
		listView.setAdapter(listAdapter);
		if (mailCounter > RELOAD_INTERVALL) {
			listView.setSelectionFromTop(mailCounter-RELOAD_INTERVALL +1, 0);
		}

	}

	protected void mailAnswer(String subject, String to) {
		Intent intent = new Intent(MailActivity.this, Answer.class);
		intent.putExtra(USER_KEY, user);
		intent.putExtra(PASSWORD_KEY, password);
		intent.putExtra(USERADRESS_KEY, userAdress);
		intent.putExtra(RECIPIENTS_KEY, to);
		intent.putExtra(SUBJECT_KEY, subject);
		startActivity(intent);
	}

}