package de.ur.mi.android.excercises.starter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ThreadActivity extends Activity {
	
	private TextView title;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_thread);
		Intent intent = getIntent();
		title = (TextView) findViewById(R.id.thread_title);
		title.setText(intent.getStringExtra(CourseActivity.NAME_KEY));
		
		
	}

}
