/** Automatically generated file. DO NOT MODIFY */
package de.ur.mi.mspwddhs.campusapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}