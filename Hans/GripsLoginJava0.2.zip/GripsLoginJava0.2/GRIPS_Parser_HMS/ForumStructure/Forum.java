package ForumStructure;
import java.util.ArrayList;

import CourseStructure.Link;


public class Forum {
	private ArrayList<Link> forum;
	private String url;
	
	public Forum(String url){
		this.url = url;
		forum = new ArrayList<Link>();
	}
	
	public ArrayList<Link> getForum(){
		return forum;
	}
	
	public String getUrl(){
		return url;
	}
}
