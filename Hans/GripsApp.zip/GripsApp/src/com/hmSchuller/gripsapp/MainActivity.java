package com.hmSchuller.gripsapp;

import java.util.ArrayList;

import CourseData.CourseListAdapter;
import CourseStructure.Course;
import Parse.ParseController;
import Parse.ParseController.OnParseListener;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity implements OnParseListener {
	CourseListAdapter courseAdapt;
	ParseController parse;
	ExpandableListView list;
	TextView view;
	EditText user;
	EditText pass;
	Button button;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		list = (ExpandableListView) findViewById(R.id.courseList);
		parse = new ParseController(this, this);
		pass = (EditText) findViewById(R.id.editTextPass);
		user = (EditText) findViewById(R.id.editTextUser);
		button = (Button) findViewById(R.id.button1);
		button.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				parse.login();
				button.setVisibility(View.GONE);
				pass.setVisibility(View.GONE);
				user.setVisibility(View.GONE);
				view = (TextView) findViewById(R.id.textView1);
				view.setVisibility(View.GONE);
				view = (TextView) findViewById(R.id.textView2);
				view.setVisibility(View.GONE);
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public String getPass() {
		System.out.println(pass.getText().toString());
		return pass.getText().toString();
	}

	@Override
	public String getUser() {
		System.out.println(user.getText().toString());
		return user.getText().toString();
	}

	@Override
	public void OnUpdateFinished(ArrayList<Course> courses) {
		System.out.println("got the List");
		courseAdapt = new CourseListAdapter(courses, this);
		System.out.println("1");
		System.out.println("2");
		list.setAdapter(courseAdapt);
		System.out.println("4");
		list.setGroupIndicator(null);
		System.out.println("all good");
		list.setVisibility(View.VISIBLE);
		System.out.println("3");
	}
}
