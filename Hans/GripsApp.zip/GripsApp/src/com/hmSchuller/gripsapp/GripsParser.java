package com.hmSchuller.gripsapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import CourseStructure.Course;
import CourseStructure.Link;
import ForumStructure.Forum;


@SuppressWarnings("deprecation")
public class GripsParser {

	static ArrayList<Course> myCourses;
	static CookieStore cookieStore;

	public static void main(String[] args) {
		myCourses = new ArrayList<Course>();
		String domainName = "https://elearning.uni-regensburg.de/login/index.php";
		String username = getUser();
		String password = getPass();
		System.out.println("Connecting to GRIPS");
		String loginHtml = loginToGrips(domainName, username, password);
		getMyCourses(loginHtml);
		for (int i = 0; i < myCourses.size(); i++) {
		}
		parseAllMyCourses();
		for (int i = 0; i < myCourses.size(); i++) {
			System.out.println("-------" + myCourses.get(i).getCourse().text()
					+ "-------");
			for (int j = 0; j < myCourses.get(i).getForumLinks().size(); j++) {
				System.out.println(myCourses.get(i).getForumLinks().get(j)
						.getName());
			}
			System.out.println(myCourses.get(i).getGrades().getName());
		}
		for(int i = 0; i < myCourses.size(); i ++){
			parseForum(myCourses.get(i), i);
		}
	}

	private static void getMyCourses(String url) {
		Document doc = Jsoup.parse(url, "ISO-8859-1");
		Elements links = doc.select("a[href]");
		for (Element link : links) {
			if (link.toString().contains("/course/view.php?id=")) {
				if (!(link.toString().contains("9090") || link.toString()
						.contains("5506"))) {
					myCourses.add(new Course(link));
				}
			}
		}
	}

	private static void parseAllMyCourses() {
		for (int i = 0; i < myCourses.size(); i++) {
			String html = getHttpFromUrl(myCourses.get(i).getCourse()
					.attr("abs:href"));
			parseCourse(html, i);
		}
	}

	private static void parseCourse(String url, int i) {
		Document doc = Jsoup.parse(url);
		Elements links = doc.select("a[href]");
		for (Element link : links) {
			if (link.toString().contains("/mod/forum/view.php?")
					&& !link.text().contains("ltere Beitr")) {
				myCourses.get(i).saveForum(link);
				myCourses.get(i).getForums()
						.add(new Forum(link.attr("abs:href")));
			}
			if (link.toString().contains("/grade/report/index.php?")) {
				myCourses.get(i).saveGrades(link);
			}
		}
	}

	private static String loginToGrips(String url, String username,
			String password) {
		String result = "";
		cookieStore = new BasicCookieStore();
		@SuppressWarnings("resource")
		AbstractHttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);
		try {
			final List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("realm", "ur"));
			nameValuePairs.add(new BasicNameValuePair("username", username));
			nameValuePairs.add(new BasicNameValuePair("password", password));
			nameValuePairs.add(new BasicNameValuePair("rememberusername", "1"));
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			cookieStore = client.getCookieStore();
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				result += line;
			}
			System.out.println(result);
		} catch (final IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	private static void parseForum(Course course, int courseID) {
		for (int i = 0; i < course.getForums().size(); i++) {
			try {
				String html = getHttpFromUrl(course.getForums().get(i).getUrl());
			Document doc = Jsoup.parse(html);
			Element forum = doc.getElementsByClass("forumheaderlist").first();
			Elements rows = forum.getElementsByTag("tr");

			for (Element row : rows) {
				Element topic = row.select("td").select(".topic")
						.select("a[href]").first();
				Element author = row.select("td").select(".author").select("a[href]").first();
				// System.out.println(el);
				if (topic != null) {
					myCourses.get(courseID).getForums().get(i).getForum()
							.add(new Link(topic.text(), topic.attr("abs:href")));
				
				}
//				System.out.println(row.select("td").select(".topic")
//						.select("a[href]"));
			}

			for (int j = 0; j < myCourses.get(courseID).getForums()
					.get(i).getForum().size(); j++) {
				System.out.println(myCourses.get(courseID).getForums()
						.get(i).getForum().get(j).getName());
			}
			} catch (Exception e) {
				System.out.println("Leeres Forum. Geil...");
			}
			

		}

	}
	
	private static void parseThreads(){
		
	}

	private static String getHttpFromUrl(String url) {
		String result = "";
		@SuppressWarnings("resource")
		AbstractHttpClient client = new DefaultHttpClient();
		client.setCookieStore(cookieStore);
		HttpPost post = new HttpPost(url);
		try {
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				// System.out.println(line);
				result += line;
			}
			System.out.println(result);
		} catch (final IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	private static String getUser() {
		return "sch26549";
	}

	private static String getPass() {
		return "nein1er22";
	}
}