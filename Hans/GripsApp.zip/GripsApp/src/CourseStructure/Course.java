package CourseStructure;
import java.util.ArrayList;

import org.jsoup.nodes.Element;

import ForumStructure.Forum;


public class Course {
	
	private ArrayList<Link> forumList;
	private Link grades;
	private Element course;
	private ArrayList<Forum> forums;
	
	
	public Course(Element course){
		this.course = course;
		forumList = new ArrayList<Link>();
		forums = new ArrayList<Forum>();
	}
	
	public Element getCourse(){
		return course;
	}
	
	public ArrayList<Link> getForumLinks(){
		return forumList;
	}
	
	public ArrayList<Forum> getForums(){
		return forums;
	}
	
	public void saveForum(Element element){
		Link link = new Link(element.text(), element.attr("abs:href"));
		forumList.add(link);
	}
	
	public Link getGrades(){
		if(grades == null){
			return new Link("Keine Bewertung!", "Keine Bewertungs-URL!");
		}
		return grades;
	}
	
	public void saveGrades(Element element){
		grades = new Link(element.text(), element.attr("abs:href"));
	}
	
	
	}
