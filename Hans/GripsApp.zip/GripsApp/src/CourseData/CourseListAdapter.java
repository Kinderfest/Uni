package CourseData;

import java.util.ArrayList;
import com.hmSchuller.gripsapp.R;
import CourseStructure.Course;
import CourseStructure.Link;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

public class CourseListAdapter extends BaseExpandableListAdapter {
	private ArrayList<Course> data;
	private Context context;

	public CourseListAdapter(ArrayList<Course> data, Context context) {
		this.data = data;
		this.context = context;
	}

	@Override
	public int getGroupCount() {
		return data.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return data.get(groupPosition).getForumLinks().size();
	}

	@Override
	public Object getGroup(int groupPosition) {

		return data.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return data.get(groupPosition).getForumLinks().get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		Course course = (Course) getGroup(groupPosition);

		if (convertView == null) {
			LayoutInflater inflate = (LayoutInflater) this.context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflate.inflate(R.layout.list_item, null);
		}
		TextView title = (TextView) convertView
				.findViewById(R.id.list_title_name);
		title.setText(course.getCourse().text());
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		Course course = (Course) getGroup(groupPosition);
		Link link = course.getForumLinks().get(childPosition);

		if (convertView == null) {
			LayoutInflater inflate = (LayoutInflater) this.context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflate.inflate(R.layout.list_item, null);
		}
		TextView title = (TextView) convertView
				.findViewById(R.id.list_item_name);
		title.setText(link.getName());

		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return false;
	}

}
