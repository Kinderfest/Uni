package ForumStructure;
import java.util.ArrayList;


public class Thread {
	private ArrayList<Post> thread;
	private String url;
	
	
	public Thread(ArrayList<Post> thread, String url){
		this.thread = thread;
	}
	
	public ArrayList<Post> getThread(){
		return thread;
	}
}
