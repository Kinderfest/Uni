package ForumStructure;
import java.util.Date;


public class Post {
	private String author;
	private Date date;
	private String post;
	
	public Post(String author, String post, Date date){
		
		this.author = author;
		this.post = post;
		this.date = date;
	}
	
	public String getAuthor(){
		return author;
	}
	
	public String getPost(){
		return post;
	}
	
	public Date getDate(){
		return date;
	}
	
}


