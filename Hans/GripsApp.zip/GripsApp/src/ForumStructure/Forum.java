package ForumStructure;
import java.util.ArrayList;

import CourseStructure.Link;


public class Forum {
	private ArrayList<Link> forum;
	private String url;
	
	public Forum(String url){
		this.url = url;
		forum = new ArrayList<Link>();
	}
	
	public ArrayList<Link> getForum(){
		return forum;
	}
	
	public String getUrl(){
		return url;
	}
	
	public String getAuthor(){
		return "";
	}
	
	private class ForumLink extends Link{
		private String author;

		public ForumLink(String name, String url, String author) {
			super(name, url);
			this.author = author;
			// TODO Auto-generated constructor stub
		}
		
		
		
	}
}
