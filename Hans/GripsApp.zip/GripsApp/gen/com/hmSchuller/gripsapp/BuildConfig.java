/** Automatically generated file. DO NOT MODIFY */
package com.hmSchuller.gripsapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}