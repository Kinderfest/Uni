package de.ur.mi.android.excercises.starter;

import android.app.Activity;

public class ResultListActivity extends Activity {

}
