package de.ur.mi.mspwddhs.campusapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import de.ur.mi.mspwddhs.campusapp.database.Database;
import de.ur.mi.mspwddhs.campusapp.mensa.MensaActivity;
import de.ur.mi.mspwddhs.campusapp.plan.PlanActivity;


public class MainActivity extends Activity{
	EditText user;
	EditText pass;
	EditText email;
	Button button;
	Database db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout); 
        db = new Database(this);
        db.open();
        if(db.isLoginTableEmpty()){
        pass = (EditText) findViewById(R.id.editTextPass);
		user = (EditText) findViewById(R.id.editTextUser);
		email = (EditText) findViewById(R.id.editTextEmail);
		button = (Button) findViewById(R.id.button1);
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				db.saveLoginData(user.getText().toString(), pass.getText().toString(), email.getText().toString());
				changeToMensa();
			}

		});
		
        } else {
        	changeToMensa();
        }
        

    }

    private void changeToMensa() {
		Intent intent = new Intent(MainActivity.this, MensaActivity.class);
		startActivity(intent);
		finish();
	}
    
//
//    private void doIt() {
//    		buttonGrips = (ImageButton) findViewById(R.id.grips);
//    		buttonMensa = (ImageButton) findViewById(R.id.mensa);
//    		buttonEmail = (ImageButton) findViewById(R.id.mail);
//    	}
//    
//    public void onClick(View v) {
//    	buttonGrips.setBackgroundColor(getResources().getColor(R.color.light_grey));
//    	buttonMensa.setBackgroundColor(getResources().getColor(R.color.light_grey));
//    	buttonEmail.setBackgroundColor(getResources().getColor(R.color.light_grey));
//    	ImageButton ClickedButton = (ImageButton) findViewById(v.getId());
//    	ClickedButton.setBackgroundColor(getResources().getColor(R.color.heidenelke));
//    	if (ClickedButton == buttonMensa) {
//    		Intent mensa = new Intent(MainActivity.this, MensaActivity.class);
//    		mensa.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
//    		startActivity(mensa);
//    	}
//    	if (ClickedButton == buttonGrips) {
//    		Intent grips = new Intent(MainActivity.this, GripsActivity.class);
//    		grips.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
//    		startActivity(grips);
//    	}
//    	if (ClickedButton == buttonEmail) {
//    		Intent mail = new Intent(MainActivity.this, MailActivity.class);
//    		mail.addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
//    		startActivity(mail);
//    	}
//    }

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
        case R.id.about:
//        	startActivity(new Intent(this, AboutActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION));  	
        	return true;
        case R.id.help:
//        	startActivity(new Intent(this, Help.class));
        	return true;
        case R.id.campusplan:
        	startActivity(new Intent(this, PlanActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION));  	
        	return true;
        case R.id.action_settings:
//        	startActivity(new Intent(this, Help.class));
            return true;
        case R.id.logout:
//        	db.logout(); //löscht Login Daten, Grips und Email
            return true;
        default:
        return super.onOptionsItemSelected(item);
    }
}
}
