import java.util.ArrayList;
import java.util.HashMap;

import org.jsoup.nodes.Element;


public class Course {
	
	private ArrayList<Link> courseList;
	private Element course;
	
	public Course(Element course){
		this.course = course;
		courseList = new ArrayList<Link>();
	}
	
	public Element getCourse(){
		return course;
	}
	
	public ArrayList<Link> getCourseList(){
		return courseList;
	}
	
	public void saveCourse(Element element){
		Link link = new Link(element.text(), element.attr("abs:href"));
		courseList.add(link);
	}
	
	
	}
