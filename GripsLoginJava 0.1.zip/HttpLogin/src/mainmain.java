import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class mainmain {

	static ArrayList<Course> myCourses;
	static CookieStore cookieStore;
	static HttpContext localContext;

	public static void main(String[] args) {

		myCourses = new ArrayList<Course>();

		String domainName = "https://elearning.uni-regensburg.de/login/index.php";
		String username = getUser();
		String password = getPass();
		System.out.println("Connecting to GRIPS");

		String loginHtml = loginToGrips(domainName, username, password);
		getMyCourses(loginHtml);
		for (int i = 0; i < myCourses.size(); i++) {
		}
		parseAllMyCourses();

		for (int i = 0; i < myCourses.size(); i++) {
			System.out.println(myCourses.get(i).getCourse().text());
			for(int j = 0; j < myCourses.get(i).getCourseList().size(); j++){
				
				System.out.println(myCourses.get(i).getCourseList().get(j).getName());
//				System.out.println(myCourses.get(i).getCourseList().get(j).getUrl());
			}
		}
		
		System.out.println("���");
		

	}

	private static void getMyCourses(String url) {
		Document doc = Jsoup.parse(url, "ISO-8859-1");
		Elements links = doc.select("a[href]");
		for (Element link : links) {
			if (link.toString().contains("/course/view.php?id=")) {
				if (!(link.toString().contains("9090") || link.toString()
						.contains("5506"))) {
					myCourses.add(new Course(link));
				}
			}
		}
	}

	private static void parseAllMyCourses() {
		for (int i = 0; i < myCourses.size(); i++) {
			String html = getHttpFromUrl(myCourses.get(i).getCourse()
					.attr("abs:href"));
			parseCourse(html, i);
		}

	}

	private static void parseCourse(String url, int i) {
		Document doc = Jsoup.parse(url);
		Elements links = doc.select("a[href]");
		for (Element link : links) {
			if (link.toString().contains("/mod/forum/view.php?")
					&& !link.text().contains("ltere Beitr")) {
				myCourses.get(i).saveCourse(link);
			}
			if (link.toString().contains("/grade/report/index.php?")) {
				myCourses.get(i).saveCourse(link);
			}
		}
	}

	@SuppressWarnings("deprecation")
	private static String loginToGrips(String url, String username,
			String password) {

		String result = "";

		cookieStore = new BasicCookieStore();
		localContext = new BasicHttpContext();
		@SuppressWarnings("deprecation")
		AbstractHttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);
		try {
			final List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("realm", "ur"));
			nameValuePairs.add(new BasicNameValuePair("username", username));
			nameValuePairs.add(new BasicNameValuePair("password", password));
			nameValuePairs.add(new BasicNameValuePair("rememberusername", "1"));

			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			localContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);
			HttpResponse response = client.execute(post);
			cookieStore = client.getCookieStore();
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				result += line;
			}
			System.out.println(result);
		} catch (final IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	@SuppressWarnings("deprecation")
	private static String getHttpFromUrl(String url) {
		String result = "";
		@SuppressWarnings({ "deprecation", "resource" })
		AbstractHttpClient client = new DefaultHttpClient();
		client.setCookieStore(cookieStore);
		HttpPost post = new HttpPost(url);
		try {
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				// System.out.println(line);
				result += line;
			}
			System.out.println(result);
		} catch (final IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	private static String getUser() {
		// TODO Auto-generated method stub
		return "sch26549";
	}

	private static String getPass() {
		// TODO Auto-generated method stub
		return "nein1er22";
	}
}
